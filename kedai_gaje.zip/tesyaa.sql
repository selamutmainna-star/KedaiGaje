CREATE DATABASE Kedai_Gaje;
USE Kedai_Gaje;
CREATE TABLE admin (
    id_admin INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(100),
    no_telp VARCHAR(15)
);
CREATE TABLE produk (
    id_produk INT AUTO_INCREMENT PRIMARY KEY,
    nama_produk VARCHAR(100),
    gambar VARCHAR(100),
    harga DOUBLE,
    status_menu ENUM('ada', 'habis') DEFAULT 'ada'
);
CREATE TABLE pembeli (
    id_pembeli INT AUTO_INCREMENT PRIMARY KEY,
    nama_pembeli VARCHAR(100),
    alamat TEXT,
    no_telp VARCHAR(15)
);
CREATE TABLE pesanan (
    id_pesanan INT AUTO_INCREMENT PRIMARY KEY,
    id_pembeli INT,
    id_produk INT,
    tipe_layanan ENUM('diantar', 'take away', 'makan disini'),
    catatan TEXT,
    metode_bayar ENUM('cash', 'transfer'),
    tanggal_pesanan TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_harga DOUBLE,
    FOREIGN KEY(id_pembeli) REFERENCES pembeli(id_pembeli),
    FOREIGN KEY(id_produk) REFERENCES produk(id_produk)
);
INSERT INTO produk(nama_produk, gambar, harga)
VALUES
('Risol Mayo', 'risol.jpg', 5000),
('Dadar Gulung', 'dadar.jpg', 3000),
('Lumpia', 'lumpia.jpg', 4000);

