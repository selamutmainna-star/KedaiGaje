Letakkan gambar berikut di folder ini:
- logo.jpg
- m1.jpg .. m8.jpg (makanan)
- d1.jpg .. d8.jpg (minuman)
Jika tidak punya gambar, buat file bernama gambar.jpg atau gunakan placeholder.