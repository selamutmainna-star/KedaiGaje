<?php
session_start();

// Daftar menu (10 makanan + 10 minuman)
$menu = [
    ['id'=>1,'type'=>'Makanan','name'=>'Nasi Goreng','price'=>15000,'img'=>'nasgor.png'],
    ['id'=>2,'type'=>'Makanan','name'=>'Mie Goreng Spesial','price'=>15000,'img'=>'mie.png'],
    ['id'=>3,'type'=>'Makanan','name'=>'Nasi Ayam Lalap','price'=>20000,'img'=>'lalap.png'],
    ['id'=>4,'type'=>'Makanan','name'=>'Nasi Ayam Penyet','price'=>30000,'img'=>'penyet.png'],
    ['id'=>5,'type'=>'Makanan','name'=>'Nasi Rendang Sapi','price'=>23000,'img'=>'rendang.png'],
    ['id'=>6,'type'=>'Makanan','name'=>'Nasi Sambal Tongkol','price'=>23000,'img'=>'sambal.png'],
    ['id'=>7,'type'=>'Makanan','name'=>'Siomay','price'=>12000,'img'=>'siomay.png'],
    ['id'=>8,'type'=>'Makanan','name'=>'Batagor','price'=>12000,'img'=>'batagor.png'],
    ['id'=>9,'type'=>'Minuman','name'=>'Pentol Goreng','price'=>17000,'img'=>'pentol.png'],
    ['id'=>10,'type'=>'Minuman','name'=>'Tahu Bakso','price'=>15000,'img'=>'tahu.png'],
    ['id'=>11,'type'=>'Minuman','name'=>'Es Teh Manis','price'=>5000,'img'=>'teh.png'],
    ['id'=>12,'type'=>'Minuman','name'=>'Kopi Hitam','price'=>5000,'img'=>'kopi.png'],
    ['id'=>13,'type'=>'Minuman','name'=>'Es Kopi Susu','price'=>6000,'img'=>'kosu.png'],
    ['id'=>14,'type'=>'Minuman','name'=>'Es Jeruk Peras','price'=>8000,'img'=>'jeruk.png'],
    ['id'=>15,'type'=>'Minuman','name'=>'Squash Melon','price'=>12000,'img'=>'melon.png'],
    ['id'=>16,'type'=>'Minuman','name'=>'Milkshake RedValvet','price'=>12000,'img'=>'red.png'],
    ['id'=>17,'type'=>'Minuman','name'=>'Milkshake Coklat','price'=>12000,'img'=>'coklat.png'],
    ['id'=>18,'type'=>'Minuman','name'=>'Milkshake Strawberry','price'=>12000,'img'=>'str.png'],
    ['id'=>19,'type'=>'Minuman','name'=>'Milkshake Taro','price'=>12000,'img'=>'taro.png'],
    ['id'=>20,'type'=>'Minuman','name'=>'Milkshake Milo','price'=>12000,'img'=>'milo.png'],
];

function rupiah($n): string {
    return 'Rp ' . number_format($n, 0, ',', '.');
}

$success = isset($_GET['success']);
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kedai Gaje Tarakan</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to bottom right,rgb(240, 246, 138) 30%,rgb(167, 222, 244) 70%);
      font-family: 'Poppins', sans-serif;
      margin: 0;
      color: #333;
    }

    /* HEADER */
    .header {
      background: linear-gradient(to right,rgb(144, 205, 246),rgb(175, 220, 247));
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.2rem 3rem;
      border-bottom: 2px solid #e3e3e3;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .logo {
      width: 90px;
      height: 90px;
      border-radius: 14px;
      object-fit: cover;
      box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
    }

    .brand h1 {
      font-size: 1.6rem;
      margin: 0;
      color: #1e3a4b;
    }

    .brand p {
      font-size: 0.9rem;
      color: #555;
      margin: 0.2rem 0 0;
    }

    .contact {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 0.3rem;
    }

    .contact a {
      color: #1e3a4b;
      text-decoration: none;
      font-size: 0.95rem;
      transition: color 0.2s;
    }

    .contact a:hover {
      color: #007b91;
    }

    /* LAYOUT UTAMA */
    .container {
      display: grid;
      grid-template-columns: 1fr 320px;
      gap: 2.5rem;
      padding: 2rem 4rem;
      align-items: start;
    }

    /* MENU */
    .menu-list h2 {
      text-align: center;
      color: #1e3a4b;
      margin-bottom: 1.2rem;
      font-size: 1.5rem;
    }

    .menu-list .grid {
      display: grid;
      grid-template-columns: repeat(5, 1fr); /* tampil 5 kolom */
      gap: 1.5rem;
        }

    .card {
      background: #ffffffdd;
      border-radius: 16px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      padding: 1rem;
      text-align: center;
      transition: transform 0.2s, box-shadow 0.2s;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 15px rgba(0,0,0,0.15);
    }

    .card img {
      width: 100%;
      height: 160px;
      object-fit: cover;
      border-radius: 12px;
    }

    .card h3 {
      color: #2b4d63;
      margin: 0.5rem 0;
      font-size: 1.05rem;
    }

    .price {
      color: #555;
      font-weight: bold;
    }

    .btn.add {
      background: #b6e3f5;
      border: none;
      color: #1e3a4b;
      padding: 8px 14px;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.2s;
      font-weight: 500;
    }

    .btn.add:hover {
      background: #a3d9ee;
    }

    /* PANEL PESANAN */
    .order-panel {
      background: #ffffffdd;
      padding: 1.5rem;
      border-radius: 14px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.12);
      color: #2b4d63;
      position: sticky;
      top: 2rem;
    }

    .order-panel h2 {
      margin-top: 0;
      font-size: 1.3rem;
      color: #1e3a4b;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    label {
      display: block;
      margin-top: 0.7rem;
      font-weight: 500;
    }

    input, textarea, select {
      width: 100%;
      padding: 8px;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-top: 4px;
      font-family: 'Poppins', sans-serif;
    }

    textarea {
      resize: none;
      height: 80px;
    }

    .notice {
      background: #d9f7dc;
      color: #2e7d32;
      padding: 0.6rem;
      border-radius: 8px;
      margin-bottom: 1rem;
      text-align: center;
    }

    .total {
      margin-top: 10px;
      font-weight: bold;
    }

    .btn.primary {
      background: #007b91;
      color: white;
      border: none;
      border-radius: 8px;
      padding: 10px 14px;
      margin-top: 10px;
      cursor: pointer;
      width: 100%;
      font-weight: 600;
      transition: background 0.2s;
    }

    .btn.primary:hover {
      background: #005e6e;
    }

    .footer {
      background: #fefbf6;
      border-top: 2px solid #eee;
      text-align: center;
      padding: 1rem;
      font-size: 0.9rem;
      color: #666;
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="brand">
      <img src="fotokedai.jpg" alt="Kedai Gaje" class="logo">
      <div>
        <h1>Kedai Gaje Tarakan</h1>
        <p>Jl. Aki Balak RT.03, Juata Kerikil, Kec. Tarakan Utara, Kota Tarakan, Kalimantan Utara 77116 — Buka 10:00–22:00</p>
      </div>
    </div>
    <div class="contact">
      <a href="https://wa.me/6282352456224" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
      <a href="https://www.instagram.com/kedaigaje" target="_blank"><i class="fa-brands fa-instagram"></i> Instagram</a>
    </div>
  </header>

  <main class="container">
    <section class="menu-list">
      <h2>Menu Kami</h2>
      <div class="grid">
        <?php foreach($menu as $m): ?>
        <div class="card">
          <img src="<?=htmlspecialchars($m['img'])?>" alt="<?=htmlspecialchars($m['name'])?>">
          <h3><?=htmlspecialchars($m['name'])?></h3>
          <p class="price"><?=rupiah($m['price'])?></p>
          <button class="btn add" 
                  data-id="<?=$m['id']?>" 
                  data-name="<?=htmlspecialchars($m['name'])?>" 
                  data-price="<?=$m['price']?>">Tambah</button>
        </div>
        <?php endforeach; ?>
      </div>
    </section>

    <aside class="order-panel">
      <h2><i class="fa-solid fa-receipt"></i> Pesanan</h2>

      <?php if($success): ?>
        <div class="notice">✅ Pesanan berhasil dikirim. Terima kasih telah memesan di Kedai Gaje Tarakan!</div>
      <?php endif; ?>

      <form id="orderForm" action="proses_pesan.php" method="post">
        <label>Nama</label>
        <input type="text" name="nama" required>
        <label>Alamat</label>
        <textarea name="alamat" placeholder="Alamat harus ditulis lengkap" required></textarea>
        <label>No. Telp</label>
        <input type="tel" name="telp" required>
        <label>Catatan Pesanan (Opsional)</label>
        <textarea name="catatan" placeholder="Contoh: tanpa sambal, level pedas sedang"></textarea>


        <div id="cart"></div>

        <p class="time">Tanggal & Jam: <span id="waktu"></span></p>

        <label>Pembayaran</label>
        <select name="pembayaran" id="pembayaran" required>
          <option value="Cash">Cash</option>
          <option value="Transfer">Transfer</option>
        </select>

        <input type="hidden" name="items" id="itemsField">
        <input type="hidden" name="total" id="totalField">

        <div class="total">Total: <span id="totalText">Rp 0</span></div>

        <button type="submit" class="btn primary">Kirim Pesanan</button>
      </form>
    </aside>
  </main>

  <footer class="footer">&copy; <?=date('Y')?> Kedai Gaje Tarakan</footer>

  <script>
    // Tampilkan waktu real-time di form
    const waktu = document.getElementById('waktu');
    const updateTime = () => {
        const now = new Date();
        waktu.textContent = now.toLocaleString('id-ID');
    };
    updateTime();
    setInterval(updateTime, 1000);
  </script>

  <script src="script.js"></script>
</body>
</html>
