<?php
var_dump(value: password_verify(password: 'admin123', hash: '$2y$10$u9w0p8OZzW2mQK4kN0xC6uqhQ2p4m8bJk3hQ7fZ0bQv0Q0h1Yx9uW'));
