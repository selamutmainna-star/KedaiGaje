<?php
session_start();

$dataFile = __DIR__ . '/data/menu.json';

// Jika file belum ada, buat dari daftar default
if (!file_exists($dataFile)) {
    $menu = [
        ['id'=>1,'type'=>'Makanan','name'=>'Nasi Goreng','price'=>15000,'img'=>'nasgor.png','stok'=>'ada'],
        ['id'=>2,'type'=>'Makanan','name'=>'Mie Goreng Spesial','price'=>15000,'img'=>'mie.png','stok'=>'ada'],
        ['id'=>3,'type'=>'Minuman','name'=>'Es Teh Manis','price'=>5000,'img'=>'teh.png','stok'=>'ada']
    ];
    file_put_contents($dataFile, json_encode($menu, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
} else {
    $menu = json_decode(file_get_contents($dataFile), true);
}

// Tambah / Edit / Hapus menu
if (isset($_POST['aksi'])) {
    if ($_POST['aksi'] === 'tambah') {
        $new = [
            'id' => time(),
            'type' => $_POST['type'],
            'name' => $_POST['name'],
            'price' => intval($_POST['price']),
            'img' => $_POST['img'],
            'stok' => 'ada'
        ];
        $menu[] = $new;
    } elseif ($_POST['aksi'] === 'hapus') {
        $menu = array_values(array_filter($menu, fn($m)=>$m['id'] != $_POST['id']));
    } elseif ($_POST['aksi'] === 'edit') {
        foreach ($menu as &$m) {
            if ($m['id'] == $_POST['id']) {
                $m['name'] = $_POST['name'];
                $m['price'] = intval($_POST['price']);
                $m['stok'] = $_POST['stok'];
                break;
            }
        }
    }
    file_put_contents($dataFile, json_encode($menu, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    header("Location: index.php");
    exit;
}

function rupiah($n){return 'Rp '.number_format($n,0,',','.');}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Kedai Gaje Tarakan</title>
<style>
body{font-family:Poppins, sans-serif;background:#f6f9fb;margin:0;padding:0;}
header{background:#89cff0;padding:1rem 2rem;display:flex;justify-content:space-between;align-items:center;}
.container{display:grid;grid-template-columns:3fr 1fr;gap:1.5rem;padding:1.5rem;}
.grid{display:grid;grid-template-columns:repeat(5,1fr);gap:1rem;}
.card{background:#fff;padding:1rem;border-radius:10px;text-align:center;box-shadow:0 2px 5px rgba(0,0,0,.1);}
.card img{width:100%;height:120px;object-fit:cover;border-radius:8px;}
.card h3{margin:.5rem 0;}
button{cursor:pointer;}
.add{background:#c4efff;border:none;padding:6px 10px;border-radius:8px;}
.add:disabled{background:#eee;color:#888;cursor:not-allowed;}
.admin-panel{background:#fff;padding:1rem;border-radius:10px;box-shadow:0 2px 5px rgba(0,0,0,.1);}
.admin-panel table{width:100%;border-collapse:collapse;}
.admin-panel th,td{border:1px solid #ddd;padding:6px;text-align:center;}
input,select{padding:4px 6px;}
</style>
</head>
<body>
<header>
  <h1>Kedai Gaje Tarakan</h1>
  <div><a href="?admin=1">🛠️ Mode Admin</a></div>
</header>

<div class="container">
  <section>
    <h2>Menu Kami</h2>
    <div class="grid">
      <?php foreach($menu as $m): ?>
      <div class="card">
        <img src="<?=htmlspecialchars($m['img'])?>" alt="">
        <h3><?=htmlspecialchars($m['name'])?></h3>
        <p><?=rupiah($m['price'])?></p>
        <button class="add" data-id="<?=$m['id']?>" <?=$m['stok']==='habis'?'disabled':''?>>
          <?=$m['stok']==='habis'?'Habis':'Tambah'?>
        </button>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <aside>
    <div id="cart"></div>
  </aside>
</div>

<?php if(isset($_GET['admin'])): ?>
<div class="admin-panel">
  <h2>Manajemen Menu</h2>
  <form method="post" style="margin-bottom:10px;">
    <input type="hidden" name="aksi" value="tambah">
    <input type="text" name="name" placeholder="Nama menu" required>
    <input type="number" name="price" placeholder="Harga" required>
    <select name="type"><option>Makanan</option><option>Minuman</option></select>
    <input type="text" name="img" placeholder="Nama file gambar">
    <button>Tambah</button>
  </form>

  <table>
    <tr><th>Nama</th><th>Harga</th><th>Stok</th><th>Aksi</th></tr>
    <?php foreach($menu as $m): ?>
    <tr>
      <form method="post">
        <input type="hidden" name="aksi" value="edit">
        <input type="hidden" name="id" value="<?=$m['id']?>">
        <td><input type="text" name="name" value="<?=$m['name']?>"></td>
        <td><input type="number" name="price" value="<?=$m['price']?>"></td>
        <td>
          <select name="stok">
            <option value="ada" <?=$m['stok']==='ada'?'selected':''?>>Ada</option>
            <option value="habis" <?=$m['stok']==='habis'?'selected':''?>>Habis</option>
          </select>
        </td>
        <td>
          <button>💾 Simpan</button>
      </form>
      <form method="post" style="display:inline;">
        <input type="hidden" name="aksi" value="hapus">
        <input type="hidden" name="id" value="<?=$m['id']?>">
        <button style="background:red;color:white;">🗑️ Hapus</button>
      </form>
        </td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
<?php endif; ?>

<script src="script.js"></script>
</body>
</html>
